/// Modelo de datos para un paciente en el sistema
/// Usado en la vista de administración para mostrar información de pacientes
class PacienteModel {
  final int id;
  final String username;
  final String nombre;
  final String apellidos;
  final int totalDiagnosticos;
  final DateTime? ultimoDiagnostico;

  PacienteModel({
    required this.id,
    required this.username,
    required this.nombre,
    required this.apellidos,
    required this.totalDiagnosticos,
    this.ultimoDiagnostico,
  });

  /// Nombre completo del paciente
  String get nombreCompleto => '$nombre $apellidos';

  /// Crea un PacienteModel desde un Map (respuesta de API)
  factory PacienteModel.fromJson(Map<String, dynamic> json) {
    return PacienteModel(
      id: json['id'] ?? 0,
      username: json['username'] ?? '',
      nombre: json['nombre'] ?? '',
      apellidos: json['apellidos'] ?? '',
      totalDiagnosticos: json['total_diagnosticos'] ?? 0,
      ultimoDiagnostico: json['ultimo_diagnostico'] != null
          ? DateTime.tryParse(json['ultimo_diagnostico'])
          : null,
    );
  }

  /// Convierte el modelo a Map para envío a API
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'nombre': nombre,
      'apellidos': apellidos,
      'total_diagnosticos': totalDiagnosticos,
      'ultimo_diagnostico': ultimoDiagnostico?.toIso8601String(),
    };
  }
}